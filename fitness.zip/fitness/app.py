from flask import Flask, redirect, render_template, request, url_for

app=Flask(__name__)

@app.route("/index", methods=["GET"])
def index():
    return ("<h2>Welcome to my Index Page</h2>")

@app.route("/underweight/<int:score>")
def underweight(score):
    return "The person has underweight and the score is"+ str(score)

@app.route("/healthyweight/<int:score>")
def healthyweight(score):
    return "The person has healthyweight and the score is"+ str(score)

@app.route("/overweight/<int:score>")
def overweight(score):
    return "The person has overweight and the score is"+ str(score)


@app.route("/bmi", methods=["GET","POST"])
def bmi():
    if request.method=="GET":
        return render_template('bmi.html')
    else:
        weight=float(request.bmi['weight'])
        height=float(request.bmi['height'])
        bmi=round(weight / (height ** 2))
        res=""
        if bmi < 18.5:
            res=  'underweight'
        elif 18.5 <= bmi < 25:
            res= 'healthyweight'
        else:
            res='overweight'
        return redirect(url_for(res,score=bmi))



if __name__=="__main__":
    app.run(debug=True)