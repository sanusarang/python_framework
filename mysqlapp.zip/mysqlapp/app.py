from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

students = []

@app.route('/')
def home():
    return "<h1>Welcome to the Student Registration App</h1><p><a href='/register'>Register a new student</a></p>"

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        course = request.form['course']
        students.append({'name': name, 'age': age, 'course': course})
        return redirect(url_for('student_list'))
    
    return '''
        <h2>Register a Student</h2>
        <form method="post">
            <label for="name">Name: </label>
            <input type="text" id="name" name="name" required><br>
            <label for="age">Age: </label>
            <input type="number" id="age" name="age" required><br>
            <label for="course">Course: </label>
            <input type="text" id="course" name="course" required><br>
            <input type="submit" value="Register">
        </form>
        <p><a href="/">Back to Home</a></p>
    '''



@app.route('/students')
def student_list():
    student_list_html = '<h2>Registered Students</h2><ul>'
    for student in students:
        student_list_html += f"<li>{student['name']} (Age: {student['age']}, Course: {student['course']})</li>"
    student_list_html += '</ul><p><a href="/register">Register another student</a></p>'
    return student_list_html

# Run the app
if __name__ == '__main__':
    app.run(debug=True)

