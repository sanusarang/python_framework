from flask import Flask, jsonify, request

app = Flask(__name__)

students = [
    {"id": 100, "name": "Sanika Sarang", "dept": "AIDS"},
    {"id": 101, "name": "Harsh Hate", "dept": "Comps"},
    {"id": 102, "name": "Sahil Bengu", "dept": "IT"},
    {"id": 103, "name": "Vipul Matkar", "dept": "IOT"},
    {"id": 104, "name": "Om Lande", "dept": "AIDS"},
    {"id": 105, "name": "Akarshan Gupta", "dept": "Comps"},
    {"id": 106, "name": "Aryan Nagu", "dept": "IOT"},
    {"id": 107, "name": "Aditya Rdekar", "dept": "AIDS"}
]

@app.route('/students', methods=['GET'])
def get_all():
    return jsonify(students)  # Use jsonify to return the list of students


# Variable rule
@app.route("/students/<int:student_id>", methods=['GET'])
def get_student(student_id):
    for student in students:
        if student['id'] == student_id:
            return jsonify(student)  # Use jsonify to return a single student dictionary
    
    # Returning the error if Student not found
    return jsonify({'error': 'Student detail not found'}), 404  # Add 404 status code

if __name__ == '__main__':
    app.run(debug=True)